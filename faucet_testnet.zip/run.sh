for i in {0..30000}
do
   ./faucet.sh
   sleep 1
done
